package com.cybage.workshop5;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {
		
		List<Integer> linkedList = new LinkedList<>();
		linkedList.add(32);
		linkedList.add(22);
		linkedList.add(33);
		linkedList.add(0);
		linkedList.add(10);
		linkedList.add(77);
		System.out.println(linkedList);
		
		System.out.println("Element at 4th position is: "+linkedList.get(4));
		System.out.println("Empty: "+linkedList.isEmpty());
		System.out.println(linkedList.remove(1));
		
		Iterator<Integer> iterator = linkedList.iterator();
		while(iterator.hasNext())
		{
			System.out.print(iterator.next()+" ");
		}
	}

}
