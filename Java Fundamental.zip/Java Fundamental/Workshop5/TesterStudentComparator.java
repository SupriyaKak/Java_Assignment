package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TesterStudentComparator {

	public static void main(String[] args) {
		
		List<StudentComparableDemo> student = new ArrayList<StudentComparableDemo>();
		student.add(new StudentComparableDemo(1, "Srushti", 90));
		student.add(new StudentComparableDemo(7, "John", 45));
		student.add(new StudentComparableDemo(33, "Harry", 67));
		student.add(new StudentComparableDemo(9, "Ron", 39));
		student.add(new StudentComparableDemo(10, "Ronaldo", 45));
		student.add(new StudentComparableDemo(15, "Emma", 71));
		
		System.out.println("Before Sorting: ");
		for(StudentComparableDemo students : student)
			System.out.print(students+" ");
		
		//Sorting by name
		Collections.sort(student, new Comparator<StudentComparableDemo>() {
			
			@Override
			public int compare(StudentComparableDemo student1, StudentComparableDemo student2)
			{
				return student1.getName().compareTo(student2.getName());
			}
		});
		System.out.println("\nAfter sorting by name: ");
		for(StudentComparableDemo students : student)
			System.out.print(students+" ");
		
		//Sorting by roll no
		Collections.sort(student, new Comparator<StudentComparableDemo>() {
			
			@Override
			public int compare(StudentComparableDemo student1, StudentComparableDemo student2)
			{
				return student1.getRollNo() - student2.getRollNo();
			}
		});
		
		System.out.println("\nAfter sorting by roll no: ");
		for(StudentComparableDemo students : student)
			System.out.print(students+" ");
		
		//sorting by marks
		Collections.sort(student, new Comparator<StudentComparableDemo>() {
			
			@Override
			public int compare(StudentComparableDemo student1, StudentComparableDemo student2)
			{
				return student1.getMarks() - student2.getMarks();
			}
		});
		
		
		System.out.println("\nAfter sorting by marks: ");
		for(StudentComparableDemo students : student)
			System.out.print(students+" ");
		
		
		
		

	}

}
