package com.cybage.Workshop3;
public class Rectangle extends Figure
{
private double width, height; 
public Rectangle() 
{
    //set default value to width and height
    this.width = 1;
    this.height = 1;
}
public Rectangle(double width, double height) 
{
    this.width = width;
    this.height = height;
}

public double getArea() 
{
    return width * height;
}

}   