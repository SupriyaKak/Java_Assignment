package com.cybage.workshop5;

import java.util.ArrayList;

public class ArrayListExample 
{
    public static void main(String[] args) 
    {
        ArrayList<String> list = new ArrayList<>();
         
        list.add("Abc");
        list.add("supriya");
        list.add("xyz");
        list.add("pqr");
         
        System.out.println( list.contains("Abc") );     
         
        System.out.println( list.contains("supriya") );    
    }
}