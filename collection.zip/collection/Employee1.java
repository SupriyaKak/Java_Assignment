package com.cybage.collection;

public class Employee1 {
	
		 
	    private String name;
	    private String account;
	    private Integer salary;
	 
	    public Employee1(String name, String account, Integer salary) {
	        super();
	        this.name = name;
	        this.account = account;
	        this.salary = salary;
	    }
	 
	    @Override
	    public String toString() {
	 
	        return "name: "+ this.name +" | account: "+ this.account +" | salary: "+this.salary;
	    }
	 
	    public String getName() {
	        return name;
	    }
	 
	    public void setName(String name) {
	        this.name = name;
	    }
	 
	    public String getAccount() {
	        return account;
	    }
	 
	    public void setAccount(String account) {
	        this.account = account;
	    }
	 
	    public Integer getSalary() {
	        return salary;
	    }
	 
	    public void setSalary(Integer salary) {
	        this.salary = salary;
	    }
	}

