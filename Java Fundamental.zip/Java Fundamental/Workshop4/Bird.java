package com.cybage.question4;

public class Bird implements Fly{

	public void fly() {
		System.out.println("bird can fly");
		
	}
}