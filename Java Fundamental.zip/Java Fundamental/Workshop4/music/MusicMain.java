package com.music;

import com.music.string.Veena;
import com.music.wind.Saxophone;

public class MusicMain {
	    public static void main(String args[]) {
	        Veena veena = new Veena();
	        Saxophone saxophone = new Saxophone();
	        Playable veena1=new Veena(); 
	        Playable saxophone1=new Saxophone();
	       
	       
	        
	        veena.play();
	        saxophone.play(); 
	        
	        veena1.play(); 
	        saxophone1.play();
	        
	    }
	}

