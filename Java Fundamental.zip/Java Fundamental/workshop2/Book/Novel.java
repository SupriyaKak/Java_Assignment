package Book;

public class Novel extends Book {
	
	   String author;

	public Novel(int isbn, String title, double price, String author) {
		super(isbn, title, price);
		this.author = author;
	}

	@Override
	public String toString() {
		return "Novel [author=" + author + ", isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
	}
	   
	   

}
