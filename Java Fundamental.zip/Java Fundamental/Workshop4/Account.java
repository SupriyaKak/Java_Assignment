package com.question4;

public class Account {
public double balance;
 Account()
{
    balance = 0;
   
}

Account(double initBalance)
{
	initBalance = balance;
}




 double getBalance()
{
    return balance;
}
   
}
