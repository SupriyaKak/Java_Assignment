package com.cybage.workshop5;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapIteration {

	public static void main(String[] args) {
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Supriya"," Software Engineer");
		map.put("Ram", "Hr");
		map.put("Sk", "Software Engineer");
		map.put("Kk", "Desktop support");
		map.put("Ss", "HR");
		
		//using for loop
		for(String name : map.keySet())
			System.out.println("Name: "+name);
		for(String designation : map.values())
			System.out.println("Designation: "+designation);
		
		//using while loop
		Iterator<String> iterator = map.keySet().iterator();
		while(iterator.hasNext())
		{
			String key = iterator.next();
			System.out.println("Name: "+key+"  designation: "+map.get(key));
		}

	}

}
