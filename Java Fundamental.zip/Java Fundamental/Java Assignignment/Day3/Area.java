package com.cybage.day3;

public class Area {

	   double length;
	   double breadth;
	   double radius;
	    
	   
	public void calculateArea(double length,double breadth)
	{
		System.out.println("Area of Rectangle = "+length*breadth);
	}

	//overloaded method
	public void calculateArea(double radius)
	{
		System.out.println("Area of Circle = "+(radius*radius));
	}



	public static void main(String[] args) {
		 
		Area a=new Area();
		a.calculateArea(8,2);
		a.calculateArea(3);
		

	}

}
