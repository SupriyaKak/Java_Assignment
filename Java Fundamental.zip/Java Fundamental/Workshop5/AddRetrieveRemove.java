package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.List;

public class AddRetrieveRemove {

	public static void main(String[] args) {
		
		List<String> arrayList = new ArrayList<>();
		arrayList.add("john");
		arrayList.add("t");
		arrayList.add("nick");
		arrayList.add("ram");
		arrayList.add("lili");
		
		System.out.println(arrayList);
		System.out.println("Value at 2nd position is: "+arrayList.get(2));
		
		arrayList.remove(3);
		System.out.println("After removing thrid value: "+arrayList);

	}

}
