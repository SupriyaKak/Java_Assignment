package com.cybage.exception;

public class MathOpertion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
