package com.cybage.exception;

import java.util.Scanner;

public class Test {

	  public static void main(String[] args) {

	   // declare variables
	   int age = 0;

	   // create Scanner class object
	   Scanner scan = new Scanner(System.in);

	   // read age
	   System.out.print("Enter age: ");
	   age = scan.nextInt();

	   // check age
	   try {
	     NameAgeException.checkAge(age);
	     System.out.println("enter the age.");
	     System.out.println("done.");
	   } catch(NotEligibleException e) {
	     System.out.println(e.getMessage());
	   }

	  }
	}