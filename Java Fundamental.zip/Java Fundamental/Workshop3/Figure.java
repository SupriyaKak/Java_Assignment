package com.cybage.Workshop3;



	

	public abstract class Figure 
	{

	//public abstract double getPerimeter();
	public abstract double getArea();

	}