package com.cybage.StaticImportDemo;
import static java.lang.Math.*;
public class StaticClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.sqrt(6));
		System.out.println(Math.pow(3, 3));
int n=(int) Math.sqrt(3);
System.out.println(Math.abs(3.3));
	}
	

}
