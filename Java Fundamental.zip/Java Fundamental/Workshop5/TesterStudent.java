package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TesterStudent {

	public static void main(String[] args) {
		
		List<Student> students = new ArrayList<Student>();
		students.add(new Student(11, "H", "Pune"));
		students.add(new Student(22, "abc", "solapur"));
		students.add(new Student(9, "ram", "Barshi"));
		students.add(new Student(44, "kk", "katraj"));
		students.add(new Student(55, "yammi", "Tuljapur"));
		students.add(new Student(10, "Joy", "Pune"));
		
		Collections.sort(students);
		System.out.println("After Sorting: ");
		for(Student student : students)
			System.out.println(student);

	}

}
