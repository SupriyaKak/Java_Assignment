package com.music.wind;

import com.music.Playable;

public class Saxophone implements Playable {
		public void play() {
	        System.out.println("Saxophone played");
	    }
}
