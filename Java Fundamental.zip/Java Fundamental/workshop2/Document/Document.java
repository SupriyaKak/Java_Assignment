package Document;

public class Document {
     
	 String text;
	
	public Document(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
 
	@Override
	public String toString() {
		return "Document [text=" + text + "]";
	}

	public static void main(String[] args) {
		   
		Document d=new Document("Hi");
		System.out.println(d.toString());
		d.setText("Riya");
		System.out.println(d.toString());
		
	}

}
