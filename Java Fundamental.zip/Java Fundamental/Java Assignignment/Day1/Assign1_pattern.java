package com.cybage.examples;

public class Assign1_pattern {

	public static void main(String[] args) {
		boolean flag=false;
		int c=1;
		for(int i=0;i<5;i++)
		{
			for(int j=1;j<=c;j++)
			{
				System.out.print("*");
				
			}
			if(c>=5 || flag==true)
			{
				c=c-2;
				flag=true;
			}
			if(!flag)
			{
				c=c+2;
			}
			System.out.println();
		}
		

	}

}
