package com.cybage.collection;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
 

 
public class StreamEmployee {
 
    public static void main(String a[]) {
 
        List<Employee1> empList = new ArrayList<>();
        empList.add(new Employee1("Nana G", "Accounts", 8000));
        empList.add(new Employee1("supriya Y", "Admin", 15000));
        empList.add(new Employee1("Viva V", "Security", 2500));
        empList.add(new Employee1("Amar", "Entertinment", 12500));
 
        // find employees whose salaries are above 10000
        empList.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
         empList.stream().filter(emp->emp.getName().length()>10).collect(Collectors.toList()).forEach(System.out::println);
         
    }
}

