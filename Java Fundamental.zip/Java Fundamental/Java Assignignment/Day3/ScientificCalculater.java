package com.cybage.day3;

public class ScientificCalculater extends Calculater{
	double num3;
	
	  
	
	public ScientificCalculater(double num1,double num2,double num3) {
		super(num1, num2);
		this.num3 = num3;
		System.out.println("Scientific Calculator");
	}

	
	double ModValue()
	{
		return num2%num3;
		
	}
	
	


		
		
	    
	    

}
