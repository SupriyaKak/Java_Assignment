/**
 *@author : Tabrej Mujawar
 * Assignment : Print all permutations of String.Write a Java program to print all permutations of a given String. For example, if given String is "GOD" then your program should print all 6 permutations of this string, e.g. "GOD," "OGD," "DOG," "GDO," "ODG," and "DGO."
 * Class : Permutation
 **/
package com.cybage.workshop6;

import java.util.Scanner;

public class Permutation {
       
	public void permutationOfString(String string,String result)
	{
		if(string.length()==0)
		{
			System.out.println(result+" ");
			return;
		}
		for(int i=0;i<string.length();i++)
		{
			char ch=string.charAt(i);
			String remaining=string.substring(0,i)+string.substring(i+1);
			permutationOfString(remaining,result+ch);
		}
	}
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String string=sc.next();
		Permutation permutation=new Permutation();
		permutation.permutationOfString(string," ");
		
		
	}

}
