package com.cybage.example;
import java.util.ArrayList;


public class ArrayListProgram {
	public static void main(String[] args) {
			/*
			ArrayList<Integer> list = new ArrayList<>();
			list.add(1);
			list.add(2);
			list.add(3);
			list.add(4);
			
list.remove(2);
			System.out.println("ArrayList : " +list);*/
			
			 ArrayList<String>arraylist = new ArrayList<>();
			 arraylist.add("A");
			 arraylist.add("B");
			 arraylist.add("C");
		     
			 arraylist.set(0, "Lucy");
			 arraylist.remove(1);
		      System.out.println("list is "+arraylist);
		}
	}


