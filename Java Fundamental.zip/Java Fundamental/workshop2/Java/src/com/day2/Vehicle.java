package com.day3;


public class Vehicle {
	private int regno;
	private String brand;
	private double price;
	private double mileage;
	
	public Vehicle(int regno, String brand, double price, double mileage) {
		this.regno = regno;
		this.brand = brand;
		this.price = price;
		this.mileage = mileage;
	}

	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) {
		this.regno = regno;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getMileage() {
		return mileage;
	}

	public void setMileage(double mileage) {
		this.mileage = mileage;
	}

	@Override
	public String toString() {
		return "Vehicle [regno=" + regno + ", brand=" + brand + ", price=" + price + ", mileage=" + mileage + "]";
	}
	
	  public static void main(String[] args)
	  {
		  Vehicle v1=new Vehicle(1,"unicorn",90000,70.00);
		  Vehicle v2=new Vehicle(2,"TVS",80000,90.00);
		  System.out.println("Vehicle  lowest price = "+v2.toString());
		  System.out.println("Vehicle  best mileage = "+v1.toString());
	
	  }
	

}
