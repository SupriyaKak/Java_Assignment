package com.cybage;

import java.util.Scanner;

public class Reverse {

	public static void main(String[] args) {
		  
		   System.out.println("Enter number");
		   Scanner sc=new Scanner(System.in);
		   int n=sc.nextInt();
		   int r=0;
		   while(n!=0)
		   {
			   int d=n%10;
			   r=d+r*10;
			   n=n/10;
			   
		   }
		
		   System.out.println(r);
		
	}

}
