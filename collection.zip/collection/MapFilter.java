package com.cybage.collection;

import java.util.HashMap;
import java.util.Map;

public class MapFilter {
	  public static void main(String a[]) {
	Map<Integer, String> map = new HashMap<>();
    map.put(1, "supriya");
    map.put(2, "kakade");
		
	String result = "";
	for (Map.Entry<Integer, String> entry : map.entrySet()) {
		if("something".equals(entry.getValue())){
			result = entry.getValue();
		}
	}
}
}