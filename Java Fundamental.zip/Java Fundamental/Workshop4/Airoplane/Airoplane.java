package com.cybage.question4.Airoplane;

import com.question4.Bird;
import com.question4.Fly;

public class Airoplane implements Fly {

	
	public void fly() {
		System.out.println("Aeroplname fly");
		
	}
public static void main(String args[]) {
	Fly bird=new Bird();
	bird.fly();
	Fly aeroplane=new Airoplane();
	aeroplane.fly();
}
}
