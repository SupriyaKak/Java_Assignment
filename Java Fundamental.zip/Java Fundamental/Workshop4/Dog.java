package com.cybage.workshop4;


	class Dog extends Animal {
		Dog() {
			System.out.println("Dog shouts");
		}
		void shout() {
			System.out.println("woof");
		}
	}

