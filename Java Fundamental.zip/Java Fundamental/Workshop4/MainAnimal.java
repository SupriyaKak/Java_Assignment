package com.cybage.workshop4;

public class MainAnimal {

		public static void main(String[] args) {
			Animal animal = new Animal();
			animal.shout();
			Animal cat = new Cat();
			cat.shout();
			Animal dog = new Dog();
			dog.shout();
			Animal horse = new Horse();
			horse.shout();
		}
}
