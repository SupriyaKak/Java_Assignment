package com.day3;



public class AddMatrices {

	public static void main(String[] args) {
		  
		   int[][] m1=new int[2][2];
		   m1[0][0]=11;
		   m1[0][1]=12;
		   m1[1][0]=32;
		   m1[1][1]=4;
		   
		System.out.println("Matrix 1 :");   
		for(int[] x:m1)
		{
			for(int y:x)
			{
				System.out.print(y+" ");
			}
			System.out.println();
		}
		
		   int[][] m2=new int[2][2];
		   m2[0][0]=4;
		   m2[0][1]=6;
		   m2[1][0]=5;
		   m2[1][1]=2;
		   
		System.out.println("Matrix 2 :");   
		for(int[] z:m2)
		{
			for(int d:z)
			{
				System.out.print(d+" ");
			}
			System.out.println();
		}
		   
		System.out.println("Addition of Matrix 1 & Matrix 2 :");
		
		int[][] add=new int[2][2];
		for(int i=0;i<m1.length;i++)
		{
			for(int j=0;j<m1[i].length;j++)
			{
				add[i][j]=m1[i][j]+m2[i][j];
			}
		}
		
		for(int[] k:add)
		{
			for(int n:k)
			{
				System.out.print(n+" ");
			}
			System.out.println();
		}

	}

}
