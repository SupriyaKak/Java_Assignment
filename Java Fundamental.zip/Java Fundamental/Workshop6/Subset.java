/**
 *@author : Tabrej Mujawar
 * Assignment : Given a set of integers. WAP to find subsets whose sum is equal to a given No.
 * Class : Subset
 **/
package com.cybage.workshop6;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Subset {
	
	    static boolean[][] dp;
	    
	    public static void show(ArrayList<Integer> arrayList)
	    {
	    	System.out.println(arrayList);
	    }
	    
	    public static void displaySubsets(int arr[],int i,int sum,ArrayList<Integer> list)
	    {
	    	if(i==0 && sum!=0 && dp[0][sum])
	    	{
	    		list.add(arr[i]);
	    		show(list);
	    		list.clear();
	    		return;
	    	}
	    	
	    	if(i==0 && sum==0)
	    	{
	    		show(list);
	    		list.clear();
	    		return;
	    	}
	    	
	    	if(dp[i-1][sum])
	    	{
	    		ArrayList<Integer> a = new ArrayList<>();
	    		a.addAll(list);
	    		displaySubsets(arr,i-1,sum,a);
	    	}
	    	
	    	if(sum>=arr[i] && dp[i-1][sum-arr[i]])
	    	{
	    		list.add(arr[i]);
	    		displaySubsets(arr,i-1,sum-arr[i],list);
	    	}

	    }
	    
	    public static void printAllSubsets(int arr[],int n,int sum)
	    {
	    	if(n==0 || sum<0)
	    		return;
	    	
	    	dp=new boolean[n][sum+1];
	    	for(int i=0;i<n;++i)
	    	{
	    		dp[i][0]=true;
	    	}
	    	if(arr[0]<=sum)
	    	{
	    		dp[0][arr[0]]=true;
	    	}
	    	
	    	for(int i=1;i<n;++i)
	    		for(int j=0;j<sum+1;++j)
	    		dp[i][j]=(arr[i]<=j) ? (dp[i-1][j] || dp[i-1][j-arr[i]]) :dp[i-1][j];
	    		
	    	if(dp[n-1][sum]==false)
	    	{
	    		System.out.println("There are no subsets");
	    		return;
	    	}
	    	
	    	ArrayList<Integer> al=new ArrayList<>();
	        displaySubsets(arr,n-1, sum,al);
	    	
	    }

	public static void main(String[] args) {
		
	    int[] set = { 7, 3, 2, 5, 8 };
	    int size=set.length;
	    Scanner sc=new Scanner(System.in);
	    
	    System.out.println("Enter sum");
	    int sum=sc.nextInt();
	    
	    printAllSubsets(set, size, sum);
	    

	}

}
