package Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		
		 Employee[] emp=new Employee[5];
		 emp[0]=new Employee(1,"riya","Pune",32345);
		 emp[1]=new Employee(2,"ram","pune",52345);
		 emp[2]=new Employee(3,"sita","solapur",22345);
		 emp[3]=new Employee(4,"radha","Pune",72345);
		 emp[4]=new Employee(5,"krish","Barshi",12345);
		 
		 Manager[] m=new Manager[2];
		 m[0]=new Manager(45,"Pradyumna","Pune",96332,"Software Development",10);
		 m[1]=new Manager(55,"Raj","Mumbai",43333,"Tester",10);
		 
		 for(int i=0;i<emp.length;i++)
		 {
			 System.out.println(emp[i].toString());
		 }
		 
		 for(int j=0;j<m.length;j++)
		 {
			 System.out.println(m[j].toString());
		 }
		 

	}

}
