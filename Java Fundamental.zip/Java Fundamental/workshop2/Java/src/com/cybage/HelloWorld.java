package com.cybage;

public class HelloWorld {

	public static void main(String[] args) {
		
		int a=10;
		char c='A';
		
	}

}
