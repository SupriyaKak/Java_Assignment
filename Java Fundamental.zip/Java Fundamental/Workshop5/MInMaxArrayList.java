package com.cybage.workshop5;
import java.util.*;
public class MInMaxArrayList {
	
	
public static void main(String[] args) {
		
		List<Integer> arrayList = new ArrayList<Integer>();
		arrayList.add(45);
		arrayList.add(45);
		arrayList.add(10);
		arrayList.add(33);
		arrayList.add(13);
		arrayList.add(10);
		
		System.out.println("ArrayList elements are: ");
		for(int i=0;i<arrayList.size();i++)
			System.out.print(arrayList.get(i)+" ");
		System.out.println();
		
		System.out.println("Maximun element in arrayList is: "+Collections.max(arrayList));
		System.out.println("Mininum element in arrayList is: "+Collections.min(arrayList));

	}

}

