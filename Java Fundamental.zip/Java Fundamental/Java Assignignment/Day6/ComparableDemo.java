package com.cybage.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparableDemo {

	public static void main(String[] args) {
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(new Employee(1, "Srushti", 1300));
		employeeList.add(new Employee(2, "Rahul", 2500));
		employeeList.add(new Employee(3, "Tina", 83000));
		employeeList.add(new Employee(4, "John", 3500));
		employeeList.add(new Employee(5, "Harry", 19000));
		
		Collections.sort(employeeList);//sorting by id
		for(Employee employee : employeeList )
			System.out.print(employee);
		
		//sorting by salary
		Collections.sort(employeeList, new Comparator<Employee>() {
			
			@Override
			public int compare(Employee employee1, Employee employee2) {
				return employee1.getSalary() - employee2.getSalary();
			}
		});
		System.out.println();
		for(Employee employee : employeeList )
			System.out.print(employee);

	}

}
