package com.cybage.day4;

public class RemoveUpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "SUppriya CYbage@ ";
	
		
String str = "SUppriya CYbage@ ";
		
		String strNew = str.replaceAll("([A-Z])", "");
		String strNew2 = strNew.replaceAll("\\W", "");
		String strNew3 = strNew2.replaceAll("([0-9])", "");
		System.out.println(strNew3);
	}

}
