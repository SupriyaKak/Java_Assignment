package com.day3;

public class RuntimePolym {

	  class Employee
	  {
		  int   id;
		  String name;
		  String loc;
		  
		 public Employee()
		 {
			 System.out.println("In Employee class");
		 }
		 
		 public Employee(int id, String name, String loc) {	
				this.id = id;
				this.name = name;
				this.loc = loc;
			}
		 
		 public String getDetails()
		 {
			 return "Employee  :  \n Id = "+id+" \n "+"Name = "+name+"\n"+"Location = "+loc+"\n";
		 }

		  
	  }
	  
	  class Manager extends Employee
	  {
		  String department;
		  String project;
		  
		  public Manager() {
			System.out.println("In Manager class");
		}

		public Manager(int id, String name, String location,String department, String project) {
			super(id,name,location);
			this.department = department;
			this.project = project;
		}

		
		@Override
		public String getDetails() {
			 return "Manager detail :  \n Id = "+id+" \n "+"Name = "+name+"\n"+"Loc = "+loc+"\n"+"Department = "+department+"\n"+"Project = "+project+"\n";
		}
		  
		  
		  
	  }
	
	public static void main(String[] args) {
		   RuntimePolym r=new RuntimePolym();
		   Employee e=r.new Manager(22,"Manisha","Pune","Software Development","Comp");
		  
		   System.out.println(e.getDetails());
		   
		   

	}

}
