package com.cybage.Workshop3;

public class StringWithLetterA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "This is just a sample string";  
		
		//checking whether the given string starts with "This"
		System.out.println(s.startsWith("This"));  
			
		//checking whether the given string starts with "Hi"
		System.out.println(s.startsWith("Hi"));  
	}

}
