package com.cybage.exception;

import java.util.Scanner;

//Java program to demonstrate ArrayIndexOutOfBoundException
class ArrayOutOfBondException
{
	 public static void main (String[] args)
	    {
	        try
	        {
	            int n, total, sum = 0, average;
	            
	            Scanner scanner = new Scanner(System.in);
	            System.out.println("Enter total numbers to be entered");
	            total = scanner.nextInt( );
	            
	            for (int i=0;i<total;i++)
	            {   
	                System.out.println("Enter N");               
	                n = scanner.nextInt( );
	                
	                if (n<0)
	                    throw new Exception("N must be positive");
	                
            sum = n + sum;
                average = sum/total;

	                System.out.println("Average is " + average);
	            }
	        }
	        catch (Exception e)
	        {
	        	  String message = e.getMessage();
	              System.out.println(message);
	              anotherChance();

	          }
	      }
	      public static void anotherChance()
	      {
	          System.out.println("Enter N");
	        //  n = scanner.nextInt();
	      }
	      public static void BadInput()
	      {
	          System.out.println("wrong input");
	      }
}
	       