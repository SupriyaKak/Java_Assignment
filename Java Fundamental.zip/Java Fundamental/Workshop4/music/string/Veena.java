package com.music.string;

import com.music.Playable;

public class Veena implements Playable {
	public void play() {
        System.out.println("Violin  played");
    }
}