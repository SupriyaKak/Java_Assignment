package Book;

public class Magazine extends Book {
	  
	   String type;

	public Magazine(int isbn, String title, double price, String type) {
		super(isbn, title, price);
		this.type = type;
	}

	@Override
	public String toString() {
		return "Magazine [type=" + type + ", isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
	}

	
	   
	   
	

}
