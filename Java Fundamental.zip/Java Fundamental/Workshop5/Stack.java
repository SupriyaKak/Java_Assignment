package com.cybage.workshop5;

public class Stack {
	
	private class Node
	{
		int data;
		Node next;
	}
	
	Node top;
	
	public Stack() {
		this.top = null;
	}
	
	public void push(int number)
	{
		Node temp = new Node();
		
		temp.data = number;
		temp.next = top;
		top = temp;
	}
	
	public boolean isEmpty()
	{
		return top == null;
	}
	
	public void pop(int number)
	{
		if(isEmpty())
		{
			System.out.println("No elements present in the stack!");
			return;
		}
		top = top.next;
	}
	public void display()
	{
		if(isEmpty())
		{
			System.out.println("No elements present in the stack!");
			return ;
		}
		else
		{
			Node temp = top;
			while(temp != null)
			{
				System.out.print(temp.data+" ");
				temp = temp.next;
			}
			
		}
		
	}
}
