package com.cybage.day3;

public class Figure {

	
double a,b;
public Figure(double a,double b)

{
	super();
	this.a=a;
	this.b=b;
	
}
	
public double area() {
	System.out.println("fig is not selected");
	return 0.0;
}

}
