package com.music;

public interface Playable {
	public void play();
}
