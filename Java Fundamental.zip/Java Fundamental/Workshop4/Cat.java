package com.cybage.workshop4;


	class Cat extends Animal {
		Cat() {
			System.out.println("Cat shouts");
		}
		void shout() {
			System.out.println("meow.");
		}
	}

