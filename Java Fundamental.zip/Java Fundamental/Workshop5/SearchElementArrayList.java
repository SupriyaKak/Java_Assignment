package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SearchElementArrayList {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		List<Integer> list = new ArrayList<Integer>();
		list.add(10);
		list.add(90);
		list.add(2);
		list.add(-5);
		list.add(78);
		list.add(2);
		
		System.out.println(list);
		System.out.println("Enter element to search: ");
		int number = scanner.nextInt();
		
		if(list.contains(number))
			System.out.println("Element is present in the list");
		else
			System.out.println("Element not found");
	}

}
