package com.cybage.workshop4;

public class Animal {

	Animal() {
		System.out.println("Animal shouts");	
	}
	void shout() {
		System.out.println("shout.shout");
	}

	}


