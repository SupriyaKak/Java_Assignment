package com.cybage.example;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		
		List<String> array_list = new ArrayList<>();
		array_list.add("john");
		array_list.add("tom");
		array_list.add("nick");
		array_list.add("emma");
		array_list.add("lucy");
		System.out.println(array_list);
		
		array_list.add(3, "billie");
		System.out.println(array_list);
		
		array_list.set(1, "harry");
		System.out.println(array_list);
		
		array_list.remove(4);
		System.out.println(array_list);
		System.out.println("Size of Array List is: "+array_list.size());
		
		System.out.println("Index of nick is: "+array_list.indexOf("nick"));
		System.out.println("Contains: "+array_list.contains("abcd"));
		
		List<Integer> integer_arrayList = new ArrayList<>();
		integer_arrayList.add(1);
		integer_arrayList.add(3);
		integer_arrayList.add(44);
		integer_arrayList.add(9);
		integer_arrayList.add(10);
		System.out.println(integer_arrayList);
		System.out.println("Size of Array List is: "+integer_arrayList.size());
		System.out.println(integer_arrayList.lastIndexOf(9));
		

	}

}
