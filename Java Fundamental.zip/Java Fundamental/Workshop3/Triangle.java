package com.cybage.Workshop3;

public  class Triangle extends Figure {

	
	private double width1,height1;
	public Triangle(double width1, double length1) 
	{
	    //set default value to width and height
	    this.width1 = 1;
	    this.height1 = 1;
	}
	public double Rectangle(double width1, double height1) 
	{
	    this.width1 = width1;
	    return this.height1 = height1;
	}

	public double getArea() 
	{
	    return width1* height1;
	}

}  