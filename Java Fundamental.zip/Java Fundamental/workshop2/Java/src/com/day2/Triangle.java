package com.day3;

public class Triangle extends Figure {

public Triangle(double a, double b) {
		super(a, b);
		// TODO Auto-generated constructor stub
	}

  public double area() {
	return 0.6*a*b;
}
}