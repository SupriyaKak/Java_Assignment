
/*8.  WAP to find given no is Armstrong or not.
Armstrong number is the number which is the sum of the cubes of all its unit, tens and hundred digits for three-digit numbers.

153 = 1*1*1 + 5*5*5 + 3*3*3 = 1 + 125 + 27 = 153

*/
package com.cybage.question3;

import java.util.Scanner;

public class Armstrong {
	  
	public static void main(String[] args)
	   {
	      int number, orignalnumber, remainder = 0, sum=0;
	      Scanner scanner = new Scanner(System.in);
	      System.out.println("Please enter a number: ");
	      number = scanner.nextInt();
	      orignalnumber = number;
	      while(number > 0)
	      {
	    	  remainder = number% 10;
	         number = number / 10;
	         sum = sum + ( remainder* remainder * remainder);
	      }
	      if(orignalnumber == sum)
	      {
	         System.out.println(orignalnumber + " is an Armstrong Number.");
	      }
	      else
	      {
	         System.out.println(orignalnumber + " is not an Armstrong Number.");
	      }
	      //scanner.close();
	   }
}