package com.cybage.exception;

import java.util.Scanner;

public class AgeException
{
private static int age;
static void validate() throws Exception
{ 
 Scanner scanner = new Scanner(System.in);
 System.out.println("Enter your age");
 age = scanner.nextInt();

 if(age < 18)  
 throw new Exception("Invalid Age, You are less than18");  
 else  
 System.out.println("Good");  
}  
public static void main(String[] args)
{
try
{  
 validate();  
}
catch(Exception e)
{
  System.out.println("Caught an Exception: \n "+e);
 }   
 }  
}