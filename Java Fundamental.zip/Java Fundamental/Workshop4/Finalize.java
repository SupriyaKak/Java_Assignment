package com.cybage.workshop4;

public class Finalize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Finalize finalize=new Finalize();
		finalize=null;
		System.gc();
		System.out.println("End of main method");
	}
	protected void finalize() {
		System.out.println("finalize method called here");
	}

}
