package com.cybage;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
	   
		  System.out.println("Enter number");
		  Scanner sc=new Scanner(System.in);
		  int n=sc.nextInt();
		  boolean flag=false;
		 
		  
		  for(int i=2;i<n;i++)
		  {
			  if(n%i==0)
			  {
				  flag=true;
				  break;
			  }
		  }
		  
		  if(flag==false || n==2)
		  {
			  System.out.println("Prime number");
		  }
		  else
			   System.out.println("Not a prime number");
	}

}
