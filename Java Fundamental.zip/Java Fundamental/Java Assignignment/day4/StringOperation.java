package com.cybage.day4;

public class StringOperation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName = "supriya ";
		String lastName = "kakade";
		System.out.println(firstName.concat(lastName));
		
		String s1 = "cybage";
        String s6 = "cybage";
        String s4 = new String("cybage");
        String s5 = new String("cybage");
        System.out.println(s1.substring(3,4));
        System.out.println(s6.toLowerCase());
        System.out.println(s4.toUpperCase());
        System.out.println(s5.indexOf("g"));
        



        String s="supriya";
        String s2="supriya";
        String s3="SUPRIYA";
        System.out.println(s.indexOf('b'));
        System.out.println(s.concat(s2));
        System.out.println(s.equals(s2));
        System.out.println(s==s2);
        System.out.println(s.contains(s3));
        
    }

 

}
 



	
