package com.cybage.examples;

public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello from java");
		int a=56;
		float r=0.1f;
		double d=44.44;
		int u=(int)d;
		char ab=(char)a;
		System.out.println(d);
		System.out.println(ab);
		
		
	}

}
