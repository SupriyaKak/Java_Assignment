package com.cybage.Workshop3;

public class AbstractFigure {

	


	
		public static void main(String [] args) 
		{

		    // To test Rectangle...
		    double width = 13, length = 9;
		    Figure rectangle = new Rectangle(width, length);
		    System.out.println("The rectangle width is: " + width 
		            + " and the length is: " + length
		            + "The area is: " + rectangle.getArea() + ".");

		   
		    double width1 = 20, length1 = 30;
		    Figure triangle = new Triangle(width1, length1);
		    System.out.println("The rectangle width is: " + width1
		            + " and the length is: " + length1
		            + "The area is: " + triangle.getArea() + ".");

		}}