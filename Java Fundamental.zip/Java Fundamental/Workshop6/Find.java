/**
 *@author : Tabrej Mujawar
 * Assignment :Given two arrays, 1,2,3,4,5 and 2,3,1,0,5 find which number is not present in the second array.
 * Class : Find
 **/
package com.cybage.workshop6;

public class Find {

	public static void main(String[] args) {
	   
		int[] array1={1,2,3,4,5};
		int[] array2={2,3,1,0,5};
		boolean flag=false;
		
		System.out.print("Number not present = ");
		for(int i=0;i<array1.length;i++)
		{
			for(int j=0;j<array2.length;j++)
			{
				if(array1[i]==array2[j])
				{
					flag=true;
					break;
				}
			}
			if(!flag)
			{
				System.out.print(array1[i]+" ");
			}
			flag=false;
		}
		
		
		
	}

}
