package com.cybage.exception;

import java.util.Scanner;

public class NameAgeException {

	 public static void checkAge(int age) 
             throws NameAgeException {

     if(age<=17) 
        throw new Exception(
              "Age<=17, not eligible for voting");

   }
}
			