package com.cybage.day3;

public class MainCalculater {

	public static void main(String[] args) {
		
		Calculater c=new Calculater(5,53);
		System.out.println(c.Add());
		System.out.println(c.Substract());
		System.out.println(c.Multiply());
		System.out.println(c.Divide());
		
		ScientificCalculater sc=new ScientificCalculater(5,60,5);
		System.out.println(sc.ModValue());

		

	}

}
