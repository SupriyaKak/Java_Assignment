package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(66);
		numbers.add(10);
		numbers.add(99);
		numbers.add(33);
		numbers.add(66);
		System.out.println("List with duplicate elements are: "+numbers);
		
		//coverting arraylist to set
		Set<Integer> set = new LinkedHashSet<>();
		set.addAll(numbers);
		numbers.clear();
		
		numbers.addAll(set);
		System.out.println("List without duplicate elements are: "+numbers);
		

	}

}

package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		List<Integer> numbers = new ArrayList<Integer>();
		numbers.add(12);
		numbers.add(10);
		numbers.add(98);
		numbers.add(34);
		numbers.add(12);
		System.out.println("List with duplicate elements are: "+numbers);
		
		//coverting arraylist to set
		Set<Integer> set = new LinkedHashSet<>();
		set.addAll(numbers);
		numbers.clear();
		
		numbers.addAll(set);
		System.out.println("List without duplicate elements are: "+numbers);
		

	}

}

