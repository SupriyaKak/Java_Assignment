package com.cybage.exception;

import java.time.LocalDate;

//class ThreadExample implements Runnable 
	class Thread1 extends Thread{
		   public void run() { 
			   for(int i=1;i<5;i++)    {    
		            try     {  
		                
		                Thread.sleep(1000);   
		            }catch(InterruptedException e){System.out.println(e);}    
		            System.out.println(i); 
		            System.out.println(getName()+" is running. Time is "+i);
			        System.out.println(getName()+" is running. Time is "+LocalDate.now());
		        }    
		    } 
		}
		      

		public class ThreadExample{   
		    public static void main(String[] args) throws InterruptedException {        
		       Thread t1 = new Thread1();
		       t1.setName("MyThread");
		       Thread t2 = new Thread(t1);
		       t2.setName("Thread 2");
		       t1.start();
		       Thread.sleep(1000);       
		       t2.start();      
		    }       
		}