package com.cybage.question4;

public interface Fly {
public void fly();
};

