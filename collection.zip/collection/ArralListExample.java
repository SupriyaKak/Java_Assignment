package com.cybage.collection;

import java.util.ArrayList;

public class ArralListExample {
  public static void main(String[] args) {
	  ArrayList<String> arrayList = new ArrayList<String>();  
	  arrayList.add("a");  
	  arrayList.add("b");  
	  arrayList.add("c"); 
	  arrayList.add("d");
	  arrayList.add("e");
	  
	  arrayList.forEach((n) -> {
			System.out.println((n));
		});
	  System.out.println("Original ArrayList  : " + arrayList);
	  
	  int index = 2;
	  arrayList.remove(index);
	  System.out.println("Resulting ArrayList : " + arrayList);
  }
}