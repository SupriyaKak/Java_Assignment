package com.cybage.collection;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestEmployee
{
   public static void main(String[] args) 
   {
       Employee employee1 = new Employee(1, "aTestName", "dLastName", 34);
       Employee employee2 = new Employee(2, "nTestName", "pLastName", 30);
       Employee employee3 = new Employee(3, "kTestName", "sLastName", 31);
       Employee employee4 = new Employee(4, "dTestName", "zLastName", 25);

       List<Employee> employees = new ArrayList<Employee>();
       employees.add(employee2);
       employees.add(employee3);
       employees.add(employee1);
       employees.add(employee4);

       // UnSorted List
       System.out.println(employees);

       Collections.sort(employees);

       // Default Sorting by employee id
       System.out.println(employees);

      // Collections.sort(employees, new Comparator());

       // Sorted by firstName
       System.out.println(employees);
//
   //    Collections.sort(employees, new Comparator());

       // Sorted by lastName
       System.out.println(employees);

    //   Collections.sort(employees, new Comparator());

       // Sorted by age
       System.out.println(employees);
       List<Employee>emps=employees.stream().filter((e)->e.getName().Length()>10);
   }
}


