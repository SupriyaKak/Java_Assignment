package com.cybage.day4;

import java.io.IOException;

public class Vowel {

	
		// TODO Auto-generated method stub
		
		    public static void main(String[] args)
		        throws IOException
		    {
		        String str = "SupriyaKakade";
		  
		            str = str.toLowerCase();
		  
		        
		        char[] chars = str.toCharArray();
		  
		        int count = 0;
		  
		        for (int i = 0; i < str.length(); i++)
		        {
		            // check if char[i] is vowel
		            if (str.charAt(i) == 'a' || str.charAt(i) == 'e'
		                || str.charAt(i) == 'i'
		                || str.charAt(i) == 'o'
		                || str.charAt(i) == 'u')
		            {
		                
		                count++;
		            }
		        }
		  
		       
		        System.out.println("Total no of vowels in string are: " + count);
		    }
		
	

}
