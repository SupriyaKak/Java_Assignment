package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortArrayList {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		list.add("Hello");
		list.add("Cybage");
		list.add("Pune");
		list.add("Maharashtra");
		list.add("India");
		
		System.out.println("Unsorted List: "+list);
		Collections.sort(list);
		System.out.println("Sorted List: "+list);

	}

}
