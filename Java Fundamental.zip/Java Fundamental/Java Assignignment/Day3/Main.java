package com.cybage.day3;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Figure figure1=new Triangle(12.12,23.23);
System.out.println("area of Triangle"+figure1.area());
Figure figure2=new Rectangle(1.12,2.23);
System.out.println("area of Triangle"+figure2.area());
Figure figure3=new Figure(12.00,23.00);
System.out.println("area of Triangle"+figure3.area());
	}

}
